package com.example.wahid4in1

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.PopupMenu
import android.widget.Toast
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // --- WebView গুলোকে লিঙ্ক ও লোড করা হচ্ছে ---
        val webViewTop: WebView = findViewById(R.id.webViewTop)
        val webViewBottom: WebView = findViewById(R.id.webViewBottom)
        setupWebView(webViewTop, "https://m.facebook.com/") // আপনার প্রয়োজন অনুযায়ী পরিবর্তন করুন
        setupWebView(webViewBottom, "https://tempmail.plus/") // আপনার প্রয়োজন অনুযায়ী পরিবর্তন করুন

        // --- বাটনগুলোকে লিঙ্ক করা হচ্ছে ---
        val btnSheet: Button = findViewById(R.id.btn_sheet)
        val btn2faAuth: Button = findViewById(R.id.btn_2fa_auth)
        val fabMoreOptions: FloatingActionButton = findViewById(R.id.fab_more_options)

        // আপনার নতুন স্প্রেডশীট অ্যাপের URL এখানে দিন
        val mySpreadsheetAppUrl = "YOUR_SPREADSHEET_WEB_APP_URL" // <<< এটিকে আপনার URL দিয়ে প্রতিস্থাপন করুন

        // Sheet বাটন ক্লিক করলে আপনার স্প্রেডশীট অ্যাপ খুলবে
        btnSheet.setOnClickListener {
            val intent = Intent(this, WebViewActivity::class.java)
            intent.putExtra("URL_TO_LOAD", mySpreadsheetAppUrl)
            startActivity(intent)
        }

        // 2FA Auth বাটন ক্লিক করলে 2FA ওয়েবসাইট খুলবে
        btn2faAuth.setOnClickListener {
            val intent = Intent(this, WebViewActivity::class.java)
            intent.putExtra("URL_TO_LOAD", "https://2fa-auth.com/")
            startActivity(intent)
        }

        // FAB-তে ক্লিক করলে WhatsApp ও Telegram মেনু দেখাবে
        fabMoreOptions.setOnClickListener { view ->
            val popup = PopupMenu(this, view)
            popup.menuInflater.inflate(R.menu.fab_menu, popup.menu)

            popup.setOnMenuItemClickListener { menuItem: MenuItem ->
                when (menuItem.itemId) {
                    R.id.action_whatsapp -> {
                        openLinkInBrowser("https://chat.whatsapp.com/GQ0iS4jIqiHLUgRcnT26de?mode=r_c")
                        true
                    }
                    R.id.action_telegram -> {
                        openLinkInBrowser("https://t.me/sell_instagram_facebook")
                        true
                    }
                    else -> false
                }
            }
            popup.show()
        }
    }

    // WebView সেটআপ করার জন্য সাহায্যকারী ফাংশন
    private fun setupWebView(webView: WebView, url: String) {
        webView.webViewClient = WebViewClient() // Default behavior, loads URL in the same WebView
        webView.settings.javaScriptEnabled = true // Enable JavaScript for the spreadsheet
        webView.loadUrl(url)
    }

    // ব্রাউজারে লিঙ্ক খোলার জন্য সাহায্যকারী ফাংশন
    private fun openLinkInBrowser(url: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Could not open link. No browser found.", Toast.LENGTH_SHORT).show()
        }
    }
}