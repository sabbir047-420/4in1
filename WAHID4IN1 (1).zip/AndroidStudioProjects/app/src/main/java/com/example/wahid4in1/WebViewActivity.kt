package com.example.wahid4in1

import android.graphics.Bitmap
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ProgressBar

class WebViewActivity : AppCompatActivity() {

    // WebView কে ক্লাস লেভেলে ডিক্লেয়ার করা হলো যাতে onBackPressed থেকেও ব্যবহার করা যায়
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_web_view)

        // ভিউগুলোকে লিঙ্ক করা হচ্ছে
        webView = findViewById(R.id.singleWebView)
        val progressBar: ProgressBar = findViewById(R.id.progressBar)
        val url = intent.getStringExtra("URL_TO_LOAD")

        // --- WebView-এর জন্য উন্নত সেটিংস ---

        // ১. জাভাস্ক্রিপ্ট চালু করা
        webView.settings.javaScriptEnabled = true

        // ২. আধুনিক ওয়েবসাইটের জন্য DOM Storage চালু করা (সবচেয়ে গুরুত্বপূর্ণ)
        webView.settings.domStorageEnabled = true

        // ৩. অন্যান্য প্রয়োজনীয় সেটিংস
        webView.settings.databaseEnabled = true
        webView.settings.cacheMode = WebSettings.LOAD_DEFAULT // ডিফল্ট ক্যাশ ব্যবহার করা
        webView.settings.loadWithOverviewMode = true
        webView.settings.useWideViewPort = true
        webView.settings.setSupportZoom(true)
        webView.settings.builtInZoomControls = true
        webView.settings.displayZoomControls = false

        // --- সেটিংস যোগ করা শেষ ---

        // WebViewClient সেটআপ করা হচ্ছে ProgressBar দেখানোর জন্য
        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                progressBar.visibility = View.VISIBLE // পেজ লোড শুরু হলে ProgressBar দেখান
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                progressBar.visibility = View.GONE // পেজ লোড শেষ হলে ProgressBar লুকান
            }
        }

        // URL লোড করা হচ্ছে
        if (url != null) {
            webView.loadUrl(url)
        }
    }

    /**
     * ফোনের ব্যাক বাটন চাপলে যাতে অ্যাপ থেকে বের না হয়ে
     * ওয়েবপেজের আগের পেজে ফিরে যায়, তার জন্য এই কোড।
     */
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack() // যদি পেছনে যাওয়ার পেজ থাকে, তাহলে পেছনে যাও
        } else {
            super.onBackPressed() // না থাকলে, অ্যাক্টিভিটি বন্ধ করো
        }
    }
}