plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.wahid4in1"
    compileSdk = 34 // আপনার এখানে যা ছিল, তাই রাখুন

    defaultConfig {
        applicationId = "com.example.wahid4in1"
        minSdk = 24 // আপনার এখানে যা ছিল, তাই রাখুন
        targetSdk = 34 // আপনার এখানে যা ছিল, তাই রাখুন
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = "1.8"
    }
}

dependencies {

    implementation("androidx.core:core-ktx:1.12.0") //libs.core.ktx এর পরিবর্তে
    implementation("androidx.appcompat:appcompat:1.6.1") //libs.appcompat এর পরিবর্তে
    implementation("com.google.android.material:material:1.11.0") //libs.material এর পরিবর্তে
    implementation("androidx.activity:activity-ktx:1.8.0") // libs.activity এর পরিবর্তে
    implementation("androidx.constraintlayout:constraintlayout:2.1.4") //libs.constraintlayout এর পরিবর্তে
    testImplementation("junit:junit:4.13.2") //libs.junit এর পরিবর্তে
    androidTestImplementation("androidx.test.ext:junit:1.1.5") //libs.ext.junit এর পরিবর্তে
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1") //libs.espresso.core এর পরিবর্তে

    // আমাদের নতুন লাইব্রেরিগুলো
    implementation("com.google.code.gson:gson:2.9.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
}